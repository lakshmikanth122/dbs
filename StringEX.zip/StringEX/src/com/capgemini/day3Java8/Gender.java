/**
 * 
 */
package com.capgemini.day3Java8;

/**
 * @author learning
 *
 */
public enum Gender {
	MALE,FEMALE
}
