package com.capgemini.arrays;

public class MyArray{
	 
public static void main(String args[]){
 
int month_days[ ] = {31,28,31,30,31,30,31,31,30,31,30,31};
 
System.out.println("FEB has " + month_days[1] + " days.");
 
}
 
}