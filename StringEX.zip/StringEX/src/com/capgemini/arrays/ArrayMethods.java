package com.capgemini.arrays;

public class ArrayMethods{
	public static void display(int y[])
    {
            System.out.println(y[0]);
            System.out.println(y[1]);
            System.out.println(y[2]);

    }
public static void main(String args[])
    {
    int x[] = { 1, 2, 3 };
    display(x);
    }
}
