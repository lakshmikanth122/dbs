package com.capgemini.monday;

public class MyClass1 {

    public static void main(String args[]) {
       
        /*initial matrix to rotate*/
        int[][] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
        int[][] transpose = new int[3][3]; // matrix to store transpose

        display(matrix);              // initial matrix

        for(int i=0;i<matrix.length;i++)
        {
        	for(int j=0;j<matrix.length;j++)
        	{
        		transpose[j][i]=matrix[i][j];
        	}
        }
            // call rotate method
        System.out.println();
       display(transpose);   
        // display the rotated matix
    }

	private static void display(int[][] arr) {
		// TODO Auto-generated method stub
		for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length; j++) {
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
	}
}