package com.capgemini.monday;

public class MulArray {

    public static void main(String args[]) {
       
        /*initial matrix to rotate*/
        String[][] matrix = { { "A", "B" }, { "D", "F" }};
        String[][] matrix1 = { { "A", "B" }, { "D", "E"}};
        String[][] transpose = new String[2][2]; // matrix to store transpose

        display(matrix); 
        display(matrix1); // initial matrix

        for(int i=0;i<matrix.length;i++)
        {
        	for(int j=0;j<matrix.length;j++)
        	{
        		transpose[j][i]=matrix[i][j]+matrix1[i][j];
        	}
        }
            // call rotate method
        System.out.println();
       display(transpose);   
        // display the rotated matix
    }

	private static void display(String[][] matrix) {
		// TODO Auto-generated method stub
		for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix.length; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
	}
}