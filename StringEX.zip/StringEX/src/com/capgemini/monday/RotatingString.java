package com.capgemini.monday;

import java.util.Scanner;

public class RotatingString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int rnum=sc.nextInt();
		String s1="String";
		char[] c=s1.toCharArray();
		StringBuilder sb = new StringBuilder();
		sb.append(s1);
		for (int i=0;i<s1.length();i++)
		{
			
			if(i<rnum)
			{	sb.append(c[0]);
				sb.deleteCharAt(0);
				c = sb.toString().toCharArray();
			}
			
			
			
		}
		System.out.println(c);
	}

}
