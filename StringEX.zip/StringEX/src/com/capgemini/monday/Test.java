package com.capgemini.monday;

interface Left
{
  default void m1()
  {
	  System.out.println("default Left");
  }
}

interface Right
{
  default void m1()
  {
	  System.out.println("default Right");
  }
}


public class Test implements Left,Right
{
  public void m1()
  {
    System.out.println("my own implementation");
    // or for specific one
    Left.super.m1();
  }
  public static void main(String[] args)
  {
    Test t = new Test();
    t.m1();
  }
}
