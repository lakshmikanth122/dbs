package com.capgemini.monday;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=new String("ABC");
		String s1="ABC";
		if(s.equals(s1))
		{
			System.out.println("Equals");
		}
		else if(s==s1)
		{
			System.out.println("Equals ==");
			
		}
		else
		{
			System.out.println("None else");
		}
	}

}
