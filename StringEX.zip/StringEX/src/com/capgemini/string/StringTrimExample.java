package com.capgemini.string;

public class StringTrimExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="   Hello   ";
		System.out.println(s1+"how are you");
		System.out.println(s1.trim()+"how are you");

	}

}
