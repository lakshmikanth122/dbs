package com.capgemini.string;

public class ReplaceExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Hey, welcome to Capgemini"; 
		String replaceString=s1.replace("Capgemini","Capgemini Waverock"); 
		System.out.println(replaceString); 
	}

}
