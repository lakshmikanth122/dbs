package com.capgemini.string;

public class StringLengthEx {

	

	public static void main(java.lang.String[] args) {
		String s1="hello"; 
		String s2="whatsup"; 
		System.out.println("string length is: "+s1.length());  
		System.out.println("string length is: "+s2.length()); 

	}

}
