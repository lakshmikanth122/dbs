package com.capgemini.string;

public class IsEmptyExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="";
		String s2="Hello Capgemini";
		System.out.println(s1.isEmpty());
		System.out.println(s2.isEmpty());
	}

}
