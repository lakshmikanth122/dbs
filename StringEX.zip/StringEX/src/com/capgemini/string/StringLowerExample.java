package com.capgemini.string;

public class StringLowerExample {

	public static void main(String[] args) {
		String s1="HELLO HOW Are You?";
				String s1lower=s1.toLowerCase();
				System.out.println(s1lower);

	}

}
