package com.capgemini.string;

public class ConcatExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Hello";
		String s2=s1.concat(" Iam at Capgemini Orion Building");
		System.out.println("Output "+s2);
		String s3=s2.concat("Hello This is another Concatination");
		System.out.println("\n" +s3);
	}

}
