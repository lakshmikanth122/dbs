package com.capgemini.string;

public class StringUpperExample {

	public static void main(String[] args) {
		String s1="hello how are you";  
		String s1upper=s1.toUpperCase();  
		System.out.println(s1upper);

	}

}
