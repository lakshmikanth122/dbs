package com.capgemini.string;

public class StringValueOfExample {

	public static void main(String[] args) {
		int value=20; 
		boolean b=true;
		String s1=String.valueOf(value); 
		String s2=String.valueOf(b); 
		System.out.println(s1+18); 
		System.out.println(s2+18); 

	}

}
