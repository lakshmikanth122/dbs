package com.capgemini.string;

public class ReplaceExample1 {

	public static void main(String[] args) {
		String s1="hello how are you"; 
		String replaceString=s1.replace('h','t'); 
		System.out.println(replaceString);
	}

}
